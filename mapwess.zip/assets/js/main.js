'use strict';

function close_login_dialog() {
    document.getElementById('btn_close').click();
}